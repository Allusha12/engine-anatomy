# Anatomy — skill для Claude

Пишеш одне речення, наприклад `/anatomy поясни, як працює механічний годинник`, і Claude створює інтерактивну ізометричну схему в стилі технічного креслення:

- тап по схемі розбирає предмет на підписані деталі;
- тап по деталі підсвічує її й показує, що вона робить;
- тап на порожньому місці збирає схему назад;
- під схемою кроки «Як це працює» та список деталей.

## Що потрібно

- Платний план Claude: Pro, Max, Team або Enterprise.
- У **Settings → Capabilities** увімкнено **Code execution and file creation**.

## Як встановити

**Через архів:** відкрийте **Settings → Capabilities**, у розділі **Skills** натисніть **Upload skill** і виберіть `anatomy-skill.zip` (розпаковувати не треба). Перевірте, що перемикач біля **anatomy** увімкнений.

**Через чат:** скопіюйте вміст `SKILL.md`, вставте в новий чат і напишіть «Створи з цього skill з назвою anatomy». Збережіть skill з картки, яку покаже Claude.

## Як користуватися

```
/anatomy поясни, як працює механічний годинник
/anatomy як влаштований кавовий автомат з помпою
/anatomy покажи анатомію серця
```

Або: «Використай skill anatomy, щоб пояснити…». Якщо щось не так, просто попросіть: «рознеси деталі сильніше», «зроби підписи англійською».

Схеми спрощені, пропорції умовні. Для брендових речей Claude малює загальну модель того ж типу, без фірмового дизайну.

---

# Anatomy — a Claude skill (EN)

Type one line, e.g. `/anatomy explain how a mechanical watch works`, and Claude builds an interactive isometric technical drawing: tap to disassemble, tap a part to highlight it and read what it does, tap empty space to reassemble, with step-by-step "how it works" below.

**Requires** a paid Claude plan (Pro, Max, Team, Enterprise) with **Code execution and file creation** enabled in **Settings → Capabilities**.

**Install:** **Settings → Capabilities → Skills → Upload skill**, choose `anatomy-skill.zip`, make sure **anatomy** is toggled on.
