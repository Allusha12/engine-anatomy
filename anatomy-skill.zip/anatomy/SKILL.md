---
name: "anatomy"
description: "Explain how any object, device or mechanism works as an interactive isometric line-art illustration with exploded view and labeled parts. Use for /anatomy or 'explain how X works / show anatomy of X'."
---

# Anatomy — interactive exploded-view explainer

The user writes one line, e.g. `/anatomy explain how a vinyl turntable plays sound`. You produce ONE self-contained HTML page (published as an Artifact) that shows the object as a technical-drawing-style isometric illustration which disassembles into its parts on tap/click, with labels and a step-by-step explanation of how it works.

Reply and write all page text in the user's language.

If the request names a specific branded product whose design is distinctive (a famous radio, car, gadget), draw a generic object of the same type and explain the same working principle; don't reproduce the product's design or logos. Facts and specs about the real product are fine in the text (verify current specs with a web search and cite sources in the reply).

## 1. Think first (no output yet)
- Identify the object and the question (what it does / how it works).
- List 6–12 meaningful parts, ordered bottom → top (assembly stack). For each: short name, one-line role.
- Write the working principle as 3–6 ordered steps; each step names the parts involved.
- Decide the explode axis: usually vertical (screen Y); side parts may also slide outward on X/Z. For objects that naturally split sideways (e.g. a boxer engine), explode along world X (screen offset = (0.866k, 0.5k)) and keep vertical for top/bottom parts. Big flat parts (dials, lids, shells) need enough offset to clear the small parts beneath them.

## 2. Drawing — isometric SVG built from parts
- Single inline `<svg>`; true isometric projection (30°): `iso(x,y,z) → [(x−y)·cos30°, (x+y)·0.5 − z]`. Generate all geometry from 3D primitives in JS — do NOT freehand paths:
  - convex solids: 2D convex hull of the projected bottom+top outlines (fill + stroke), then the top face — works for cylinders, discs, boxes;
  - boxes: draw the three visible faces (+y, +x, top) so every edge shows;
  - cylinders along any axis: hull of both end rings + the visible (+) end cap; circumferential bands as visible half-arcs;
  - thin plates/gears: bottom outline then top outline (teeth; holes with `fill-rule: evenodd`);
  - other convex bits (rods, webs, levers): hull of projected 3D sample points.
- Each part is its own `<g class="part" data-id="…">` with CSS vars `--dx --dy` (explode offset) and `--d` (stagger delay), containing an inner `<g>` with the geometry.
- Style = technical line drawing: `fill` = paper colour (opaque, so parts occlude each other correctly), `stroke` = ink colour, stroke-width 1–1.5, `vector-effect: non-scaling-stroke`; secondary detail lines thinner/lighter; optional dashed construction lines. No gradients, no colour except one accent for the active part.
- Draw parts back-to-front so occlusion is right (viewer sits at +x,+y,+z; depth ≈ x+y+z). Inside one part with many pieces (e.g. crank + pistons), give each piece a depth key and sort before joining. A shell that encloses other parts (case, housing) is split into a back piece drawn before its contents and a front piece drawn after them, both with the same `data-id` and offset; a lid drawn after its contents can be a full solid.
- Level of detail: recognisable silhouette + characteristic details (knobs, screws, grooves, cables, ticks), but clean.
- Optional live motion where it explains the mechanism (rotating wheels, oscillating balance, moving pistons, needle sweep): re-render only the animated parts each frame from a `state()` function.

## 3. Fit the figure
- Compute bounds at runtime: `getBBox()` of each part's inner group plus its explode offset → exploded bounds; without offsets → assembled bounds.
- Set the `viewBox` from the exploded bounds plus side margins for the label columns (≈300 units on desktop, ≈70 on narrow screens). Recompute on resize.
- The assembled state zooms in: `#scene { transform: translate(var(--tx),var(--ty)) scale(var(--s)) }`, computed so the assembled object fills ~85% of the viewBox; disassembled is `translate(0,0) scale(1)`. Transition it together with the part offsets.
- Label font size in user units = desired px × (viewBox width / rendered width), so labels stay readable at any size.

## 4. Interaction (tap/click — same on mobile and desktop)
- Default: assembled.
- Tap/click anywhere on the figure while assembled → it disassembles (parts animate apart along their offsets, ~600–700ms, ease-out cubic, slight stagger by layer).
- While disassembled:
  - tap/click any part or its label → that part is selected: accent stroke, all other parts and labels dim to ~20–30% opacity, its role sentence appears in a caption bar under the figure; tapping the same part again deselects it;
  - tap/click empty space in the figure → it reassembles and clears the selection and active step.
- Desktop extra: while disassembled, mouse hover over a part previews the same highlight + caption.
- A toggle button above the figure (Disassemble / Assemble, in the user's language) does the same as tapping.
- Leader-line labels (thin line from part to a mono caps caption, `01 PLATTER`) in left/right columns, visible only when disassembled; side chosen by anchor position, stacked with a minimum gap. On narrow screens show numbers only.
- "How it works" steps list below the figure: clicking a step disassembles, highlights that step's parts and shows the step text in the caption; clicking it again clears. Optional per-step motion (waves, needle sweep, cone pulse, flowing signal as dashed animated stroke).
- Parts list below: hover/focus previews the highlight; click selects the part (and disassembles).
- `cursor: pointer` and `-webkit-tap-highlight-color: transparent` on the figure. Respect `prefers-reduced-motion` (skip transitions and animation, keep states).

## 5. Page layout & look
- Technical-plate aesthetic: off-white paper (light) / near-black (dark), monospace small caps captions (e.g. 'JetBrains Mono' or 'IBM Plex Mono' from Google Fonts), body e.g. 'IBM Plex Sans'; check the fonts cover the page's language (Cyrillic etc.).
- Corner marks on the plate: `FIG. 01` top-left, object name top-right, `TAP — DISASSEMBLE` (in the user's language) bottom-left, a real spec bottom-right (e.g. `33⅓ RPM`, `N PARTS`); hide the bottom-left mark on narrow screens if corners collide.
- Title = the object; one-line answer to the question under it; optional row of key figures.
- Below the figure: the caption bar, then steps and numbered parts list (name + role) in two columns that stack on mobile. Add a one-line note if proportions are simplified or motion is slowed.
- Colours as CSS tokens on :root with dark mode; mobile-first, figure scales to width, no horizontal scroll.

## 6. Deliver
- Load the artifact-design skill (or run the Artifact quickstart), write the HTML file, publish with the Artifact tool (icon: `diagram`).
- Reply in 1–2 sentences: what the page shows and how to interact (tap to disassemble, tap a part to highlight it, tap empty space to reassemble, steps below).

## Quality check before publishing
- Render with Playwright (desktop + 390px mobile with `hasTouch`), screenshot assembled and disassembled states, and look: parts recognisable, occlusion correct, no label clipped or overlapping, nothing cut off.
- Simulate taps: tap the figure → disassembled; tap a label → that part gets `.on` and the caption shows its role; tap empty space → assembled. No console errors.